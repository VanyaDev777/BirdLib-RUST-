//! # bird_lib 🐦
//!
//! Simple I/O, system diagnostics, system guard, terminal UI, and matrices for Rust.

pub mod tweet;
pub mod birdwatch;
pub mod guard;
pub mod matrix;
pub mod tui;

pub mod prelude {
    pub use crate::tweet::*;
    pub use crate::birdwatch;
    pub use crate::guard;
    pub use crate::matrix;
    pub use crate::matrix::print_matrix;
    pub use crate::tui::cursor::{self, Cursor, Event_};
    pub use crate::tui::buttons::{self, Keyboard, Button, Special};
    pub use crate::tui::board::{birdboard, birdboard_command};
    pub use crate::sayf;
}