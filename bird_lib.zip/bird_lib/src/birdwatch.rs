//! System diagnostics.

use sysinfo::{System, ProcessesToUpdate};
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct ProcInfo {
    pub pid: u32,
    pub name: String,
    pub cpu: f32,
    pub memory_mb: f64,
}

#[derive(Debug, Clone)]
pub struct Health {
    pub cpu_percent: f32,
    pub ram_percent: f64,
    pub ram_used_gb: f64,
    pub ram_total_gb: f64,
    pub top_cpu: Vec<ProcInfo>,
    pub top_mem: Vec<ProcInfo>,
}

pub fn snapshot() -> Health {
    let mut sys = System::new_all();
    sys.refresh_all();
    std::thread::sleep(Duration::from_millis(300));
    sys.refresh_cpu_usage();
    sys.refresh_processes(ProcessesToUpdate::All, true);

    let cpu_percent = sys.global_cpu_usage();
    let ram_total_gb = sys.total_memory() as f64 / 1024.0 / 1024.0 / 1024.0;
    let ram_used_gb  = sys.used_memory()  as f64 / 1024.0 / 1024.0 / 1024.0;
    let ram_percent  = if ram_total_gb > 0.0 {
        (ram_used_gb / ram_total_gb) * 100.0
    } else {
        0.0
    };

    let mut procs: Vec<ProcInfo> = sys
        .processes()
        .iter()
        .map(|(pid, p)| ProcInfo {
            pid: pid.as_u32(),
            name: p.name().to_string_lossy().to_string(),
            cpu: p.cpu_usage(),
            memory_mb: p.memory() as f64 / 1024.0 / 1024.0,
        })
        .collect();

    let mut by_cpu = procs.clone();
    by_cpu.sort_by(|a, b| b.cpu.partial_cmp(&a.cpu).unwrap_or(std::cmp::Ordering::Equal));
    by_cpu.truncate(5);

    procs.sort_by(|a, b| b.memory_mb.partial_cmp(&a.memory_mb).unwrap_or(std::cmp::Ordering::Equal));
    procs.truncate(5);

    Health {
        cpu_percent,
        ram_percent,
        ram_used_gb,
        ram_total_gb,
        top_cpu: by_cpu,
        top_mem: procs,
    }
}

pub fn has_problems() -> bool {
    let h = snapshot();
    h.cpu_percent > 80.0 || h.ram_percent > 85.0
}

pub fn problems() -> Vec<String> {
    let h = snapshot();
    let mut list = Vec::new();

    if h.cpu_percent > 80.0 {
        list.push(format!("CPU overloaded: {:.1}%", h.cpu_percent));
    }
    if h.ram_percent > 85.0 {
        list.push(format!("RAM nearly full: {:.1}%", h.ram_percent));
    }
    if h.ram_percent > 95.0 {
        list.push("CRITICAL: RAM almost exhausted".to_string());
    }
    list
}

pub fn print_report() {
    use crate::tweet::say;
    use crate::sayf;

    let h = snapshot();

    say("");
    say("--- System Report ---");
    sayf!("CPU: {:.1}%", h.cpu_percent);
    sayf!("RAM: {:.2} / {:.2} GB ({:.1}%)",
          h.ram_used_gb, h.ram_total_gb, h.ram_percent);
    say("");

    say("Top CPU consumers:");
    sayf!("  {:<8} {:<25} {:>8}", "PID", "NAME", "CPU %");
    for p in &h.top_cpu {
        sayf!("  {:<8} {:<25} {:>8.1}", p.pid, p.name, p.cpu);
    }
    say("");

    say("Top RAM consumers:");
    sayf!("  {:<8} {:<25} {:>10}", "PID", "NAME", "MEM MB");
    for p in &h.top_mem {
        sayf!("  {:<8} {:<25} {:>10.1}", p.pid, p.name, p.memory_mb);
    }
    say("");

    let probs = problems();
    if probs.is_empty() {
        say("System is healthy.");
    } else {
        sayf!("Problems detected: {}", probs.len());
        for p in probs {
            sayf!("  - {}", p);
        }
    }
    say("");
}