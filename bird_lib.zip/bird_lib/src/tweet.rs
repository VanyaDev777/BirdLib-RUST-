//! Simple input/output.

use std::io::{self, Write};

/// Asks the user for a line of text.
pub fn ask(prompt: &str) -> String {
    print!("{}", prompt);
    io::stdout().flush().expect("failed to flush stdout");

    let mut line = String::new();
    io::stdin()
        .read_line(&mut line)
        .expect("failed to read line");

    line.trim().to_string()
}

/// Prints a string with a newline.
pub fn say(text: &str) {
    println!("{}", text);
}

/// Clears the terminal screen.
pub fn clear() {
    print!("\x1b[2J\x1b[H");
    let _ = io::stdout().flush();
}

/// Prints a formatted string with a newline.
#[macro_export]
macro_rules! sayf {
    ($($arg:tt)*) => {
        println!($($arg)*)
    };
}

/// Prints an integer with a newline.
pub fn say_num(n: i64) {
    println!("{}", n);
}

/// Prints a float with a newline.
pub fn say_float(x: f64) {
    println!("{}", x);
}

/// Asks the user for an integer. Repeats on invalid input.
pub fn ask_num(prompt: &str) -> i64 {
    loop {
        let line = ask(prompt);
        match line.parse::<i64>() {
            Ok(n) => return n,
            Err(_) => say("Not a number, try again."),
        }
    }
}

/// Asks the user for a float. Repeats on invalid input.
pub fn ask_float(prompt: &str) -> f64 {
    loop {
        let line = ask(prompt);
        match line.parse::<f64>() {
            Ok(x) => return x,
            Err(_) => say("Not a number, try again."),
        }
    }
}

/// Asks a yes/no question. Returns true for "y" or "yes".
pub fn ask_yes(prompt: &str) -> bool {
    ask_yes_locale(prompt, &["y", "yes"], &["n", "no"])
}

/// Asks a yes/no question with custom answer words.
pub fn ask_yes_locale(prompt: &str, yes_words: &[&str], no_words: &[&str]) -> bool {
    loop {
        let line = ask(prompt).to_lowercase();
        if yes_words.iter().any(|w| w == &line) {
            return true;
        }
        if no_words.iter().any(|w| w == &line) {
            return false;
        }
        say("Please answer yes or no.");
    }
}