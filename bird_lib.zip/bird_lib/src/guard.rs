//! # guard 🛡️
//!
//! Безопасность системы: проверка состояния, предупреждения, советы.

use crate::tweet::say;
use crate::sayf;
use crate::birdwatch;

/// Статус проверки.
#[derive(Debug, Clone)]
pub enum Status {
    Ok,
    Warning(String),
    Critical(String),
}

impl Status {
    pub fn icon(&self) -> &'static str {
        match self {
            Status::Ok => "[OK]",
            Status::Warning(_) => "[!!]",
            Status::Critical(_) => "[XX]",
        }
    }

    pub fn message(&self) -> &str {
        match self {
            Status::Ok => "OK",
            Status::Warning(msg) => msg,
            Status::Critical(msg) => msg,
        }
    }

    pub fn is_bad(&self) -> bool {
        !matches!(self, Status::Ok)
    }
}

/// Информация о диске.
#[derive(Debug, Clone)]
pub struct DiskInfo {
    pub mount: String,
    pub total_gb: f64,
    pub used_gb: f64,
    pub percent: f64,
    pub status: Status,
}

/// Полный отчёт о здоровье системы.
#[derive(Debug, Clone)]
pub struct SystemHealth {
    pub cpu: Status,
    pub ram: Status,
    pub disks: Vec<DiskInfo>,
}

/// Проверка CPU.
pub fn check_cpu() -> Status {
    let h = birdwatch::snapshot();
    let cpu = h.cpu_percent;

    if cpu < 70.0 {
        Status::Ok
    } else if cpu < 90.0 {
        Status::Warning(format!("CPU {:.1}% — высокая нагрузка", cpu))
    } else {
        Status::Critical(format!("CPU {:.1}% — КРИТИЧНО", cpu))
    }
}

/// Проверка RAM.
pub fn check_ram() -> Status {
    let h = birdwatch::snapshot();
    let ram = h.ram_percent;

    if ram < 70.0 {
        Status::Ok
    } else if ram < 85.0 {
        Status::Warning(format!("RAM {:.1}% — почти полна", ram))
    } else {
        Status::Critical(format!("RAM {:.1}% — КРИТИЧНО", ram))
    }
}

/// Проверка дисков.
pub fn check_disk() -> Vec<DiskInfo> {
    use std::process::Command;

    let out = Command::new("df").args(["-B1", "--output=target,size,used,pcent"]).output();

    let Ok(out) = out else {
        return vec![];
    };

    let text = String::from_utf8_lossy(&out.stdout);
    let mut disks = Vec::new();

    for (i, line) in text.lines().enumerate() {
        if i == 0 {
            continue;
        }
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 4 {
            continue;
        }

        let mount = parts[0].to_string();
        let total: f64 = parts[1].parse().unwrap_or(0.0);
        let used:  f64 = parts[2].parse().unwrap_or(0.0);
        let pct_str = parts[3].trim_end_matches('%');
        let percent: f64 = pct_str.parse().unwrap_or(0.0);

        if !mount.starts_with('/') {
            continue;
        }

        let status = if percent < 80.0 {
            Status::Ok
        } else if percent < 90.0 {
            Status::Warning(format!("Диск {} заполнен на {:.0}%", mount, percent))
        } else {
            Status::Critical(format!("Диск {} заполнен на {:.0}% — КРИТИЧНО", mount, percent))
        };

        disks.push(DiskInfo {
            mount,
            total_gb: total / 1024.0 / 1024.0 / 1024.0,
            used_gb: used / 1024.0 / 1024.0 / 1024.0,
            percent,
            status,
        });
    }

    disks
}

/// Полная проверка системы.
pub fn check_system() -> SystemHealth {
    SystemHealth {
        cpu: check_cpu(),
        ram: check_ram(),
        disks: check_disk(),
    }
}

/// Есть ли проблемы?
pub fn has_problems(health: &SystemHealth) -> bool {
    health.cpu.is_bad()
        || health.ram.is_bad()
        || health.disks.iter().any(|d| d.status.is_bad())
}

/// Печатает отчёт о здоровье.
pub fn print_report(health: &SystemHealth) {
    say("");
    say("=== System Health ===");
    say("");

    sayf!("  {} CPU: {}", health.cpu.icon(), health.cpu.message());
    sayf!("  {} RAM: {}", health.ram.icon(), health.ram.message());

    for disk in &health.disks {
        sayf!(
            "  {} {}: {:.1}/{:.1} GB ({:.0}%)",
            disk.status.icon(),
            disk.mount,
            disk.used_gb,
            disk.total_gb,
            disk.percent
        );
    }

    say("");

    if has_problems(health) {
        say("Problems detected. See above.");
    } else {
        say("System is healthy.");
    }

    say("");
}

/// Печатает только проблемы (если есть).
pub fn warn_if_bad() {
    let health = check_system();

    if !has_problems(&health) {
        return;
    }

    say("");
    say("--- Warnings ---");

    if health.cpu.is_bad() {
        sayf!("  {} {}", health.cpu.icon(), health.cpu.message());
    }
    if health.ram.is_bad() {
        sayf!("  {} {}", health.ram.icon(), health.ram.message());
    }
    for disk in &health.disks {
        if disk.status.is_bad() {
            sayf!("  {} {}", disk.status.icon(), disk.status.message());
        }
    }

    say("");
}