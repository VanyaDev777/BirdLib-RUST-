//! # Matrix 🎯
//!
//! Матрица = `Vec<Vec<f64>>`.

/// Создаёт матрицу — как `vec!`, но для таблиц.
#[macro_export]
macro_rules! matrix {
    ( $( [ $( $x:expr ),* ] ),* $(,)? ) => {
        vec![
            $( vec![ $( $x as f64 ),* ] ),*
        ]
    };
}

/// Печатает матрицу — формат как у `Vec` в Rust.
pub fn print_matrix(m: &[Vec<f64>]) {
    use crate::tweet::say;

    for row in m {
        let mut line = String::from("[");
        for (j, v) in row.iter().enumerate() {
            if j > 0 {
                line.push_str(", ");
            }
            line.push_str(&format!("{:.2}", v));
        }
        line.push(']');
        say(&line);
    }
}