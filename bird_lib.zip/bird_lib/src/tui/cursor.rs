//! Курсор — управляемое перемещение по экрану + мышь.

use crossterm::{
    cursor, execute,
    event::{self, DisableMouseCapture, EnableMouseCapture, Event, KeyCode, KeyEvent, MouseEvent, MouseEventKind},
    terminal::{self, ClearType},
};
use std::io::{self, Write};

pub fn enable_raw_mode() -> io::Result<()> {
    terminal::enable_raw_mode()?;
    execute!(io::stdout(), EnableMouseCapture)?;
    print!("\x1b[?1003h");
    io::stdout().flush()?;
    Ok(())
}

pub fn disable_raw_mode() -> io::Result<()> {
    print!("\x1b[?1003l");
    io::stdout().flush()?;
    execute!(io::stdout(), DisableMouseCapture)?;
    terminal::disable_raw_mode()
}

pub fn clear() -> io::Result<()> {
    execute!(io::stdout(), terminal::Clear(ClearType::All))
}

pub fn hide() -> io::Result<()> {
    execute!(io::stdout(), cursor::Hide)
}

pub fn show() -> io::Result<()> {
    execute!(io::stdout(), cursor::Show)
}

pub fn move_to(x: u16, y: u16) -> io::Result<()> {
    execute!(io::stdout(), cursor::MoveTo(x, y))
}

pub fn terminal_size() -> io::Result<(u16, u16)> {
    terminal::size()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Event_ {
    Up,
    Down,
    Left,
    Right,
    Enter,
    Escape,
    Backspace,
    Char(char),
    MouseClick(u16, u16),
    MouseMove(u16, u16),
    Resize(u16, u16),
    Other,
}

pub fn read_event() -> io::Result<Event_> {
    loop {
        match event::read()? {
            Event::Key(KeyEvent { code, .. }) => {
                return Ok(match code {
                    KeyCode::Up        => Event_::Up,
                    KeyCode::Down      => Event_::Down,
                    KeyCode::Left      => Event_::Left,
                    KeyCode::Right     => Event_::Right,
                    KeyCode::Enter     => Event_::Enter,
                    KeyCode::Esc       => Event_::Escape,
                    KeyCode::Backspace => Event_::Backspace,
                    KeyCode::Char(c)   => Event_::Char(c),
                    _                  => Event_::Other,
                });
            }
            Event::Mouse(MouseEvent { kind, column, row, .. }) => {
                return Ok(match kind {
                    MouseEventKind::Down(_) => Event_::MouseClick(column, row),
                    MouseEventKind::Moved   => Event_::MouseMove(column, row),
                    _ => Event_::Other,
                });
            }
            Event::Resize(w, h) => return Ok(Event_::Resize(w, h)),
            _ => {}
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct Cursor {
    pub x: u16,
    pub y: u16,
}

impl Cursor {
    pub fn new(x: u16, y: u16) -> Self {
        Self { x, y }
    }

    pub fn up(&mut self) {
        if self.y > 0 { self.y -= 1; }
    }

    pub fn down(&mut self) {
        if let Ok((_, rows)) = terminal_size() {
            if self.y + 1 < rows { self.y += 1; }
        }
    }

    pub fn left(&mut self) {
        if self.x > 0 { self.x -= 1; }
    }

    pub fn right(&mut self) {
        if let Ok((cols, _)) = terminal_size() {
            if self.x + 1 < cols { self.x += 1; }
        }
    }

    pub fn go_to(&mut self, x: u16, y: u16) {
        self.x = x;
        self.y = y;
    }

    pub fn apply(&self) -> io::Result<()> {
        move_to(self.x, self.y)
    }

    pub fn flush(&self) -> io::Result<()> {
        io::stdout().flush()
    }
}