//! Экранная клавиатура — `birdboard()` и `birdboard_command()`.

use crate::tui::cursor::{self, Event_};
use crate::tui::buttons::{Keyboard, Button, Special};

/// Открывает клавиатуру и возвращает введённую строку.
pub fn birdboard() -> std::io::Result<String> {
    run_board(false)
}

/// Открывает клавиатуру в режиме bash-команд (Enter выполняет).
pub fn birdboard_command() -> std::io::Result<String> {
    run_board(true)
}

fn run_board(command_mode: bool) -> std::io::Result<String> {
    cursor::enable_raw_mode()?;
    cursor::clear()?;

    let (_, rows) = cursor::terminal_size()?;

    let kb_x = 3;
    let kb_y = rows.saturating_sub(10);
    let mut kb = Keyboard::qwerty(kb_x, kb_y);

    let mut cur = cursor::Cursor::new(kb_x + 2, kb_y);
    let mut input = String::new();
    let mut running = true;

    while running {
        cursor::clear()?;

        // Инпут сверху
        print!("\x1b[1;3H=== birdboard ===");
        if command_mode {
            print!("\x1b[3;3H$ {}", input);
        } else {
            print!("\x1b[3;3H> {}", input);
        }

        // Индикатор CAPS
        if kb.caps_on {
            print!("\x1b[3;60H[CAPS]");
        }

        // Подсказка
        if command_mode {
            print!(
                "\x1b[{};3HArrows/mouse: move. Enter: run. Esc: exit.",
                rows - 1
            );
        } else {
            print!(
                "\x1b[{};3HArrows/mouse: move. Enter: type. Esc: exit.",
                rows - 1
            );
        }

        kb.draw(cur.x, cur.y);
        cur.apply()?;
        cur.flush()?;
        cursor::show()?;

        match cursor::read_event()? {
            Event_::Up    => { cur.up(); }
            Event_::Down  => { cur.down(); }
            Event_::Left  => { cur.left(); }
            Event_::Right => { cur.right(); }

            Event_::MouseMove(x, y) => {
                cur.go_to(x, y);
            }

            Event_::MouseClick(x, y) => {
                cur.go_to(x, y);
                if let Some(btn) = kb.hit(x, y) {
                    let btn = btn.clone();
                    handle_key(&mut kb, &mut input, &btn, command_mode, &mut running);
                }
            }

            Event_::Enter => {
                // Курсор НЕ на клавиатуре → выполнить/закончить
                if cur.y < kb_y {
                    running = false;
                } else if let Some(btn) = kb.hit(cur.x, cur.y) {
                    let btn = btn.clone();
                    handle_key(&mut kb, &mut input, &btn, command_mode, &mut running);
                }
            }

            Event_::Backspace => {
                input.pop();
            }

            Event_::Char(c) => {
                if c.is_alphabetic() || c == ' ' || c == '-' || c == '_' || c == '/' || c == '.' {
                    if kb.caps_on {
                        input.push(c.to_ascii_uppercase());
                    } else {
                        input.push(c.to_ascii_lowercase());
                    }
                }
            }

            Event_::Escape => {
                running = false;
            }

            _ => {}
        }
    }

    cursor::disable_raw_mode()?;
    cursor::show()?;
    Ok(input)
}

fn handle_key(
    kb: &mut Keyboard,
    input: &mut String,
    btn: &Button,
    command_mode: bool,
    running: &mut bool,
) {
    match btn.special {
        Special::None => {
            if let Some(c) = kb.char_from(btn) {
                input.push(c);
            }
        }
        Special::Space => {
            input.push(' ');
        }
        Special::Backspace => {
            input.pop();
        }
        Special::CapsLock => {
            kb.caps_on = !kb.caps_on;
        }
        Special::Enter => {
            if command_mode {
                *running = false;
            }
        }
    }
}