//! Кнопки и клавиатура.

#[derive(Debug, Clone)]
pub struct Button {
    pub label: String,
    pub x: u16,
    pub y: u16,
    pub width: u16,
    pub value: Option<char>,
    pub special: Special,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Special {
    None,
    Space,
    Backspace,
    CapsLock,
    Enter,
}

#[derive(Debug, Clone)]
pub struct Keyboard {
    pub buttons: Vec<Button>,
    pub caps_on: bool,
}

impl Keyboard {
    /// Создаёт QWERTY-клавиатуру в позиции (x, y).
    pub fn qwerty(x: u16, y: u16) -> Self {
        let mut buttons = Vec::new();
        let rows = [
            "QWERTYUIOP",
            "ASDFGHJKL",
            "ZXCVBNM",
        ];

        for (row, letters) in rows.iter().enumerate() {
            for (col, ch) in letters.chars().enumerate() {
                buttons.push(Button {
                    label: ch.to_string(),
                    x: x + (col as u16) * 4,
                    y: y + (row as u16) * 2,
                    width: 3,
                    value: Some(ch),
                    special: Special::None,
                });
            }
        }

        // Пробел
        buttons.push(Button {
            label: " ".to_string(),
            x: x,
            y: y + 6,
            width: 20,
            value: Some(' '),
            special: Special::Space,
        });

        // Backspace
        buttons.push(Button {
            label: "<-".to_string(),
            x: x + 21,
            y: y + 6,
            width: 4,
            value: None,
            special: Special::Backspace,
        });

        // Enter
        buttons.push(Button {
            label: "Enter".to_string(),
            x: x + 26,
            y: y + 6,
            width: 7,
            value: None,
            special: Special::Enter,
        });

        // CAPS
        buttons.push(Button {
            label: "CAPS".to_string(),
            x: x + 34,
            y: y + 6,
            width: 6,
            value: None,
            special: Special::CapsLock,
        });

        Self { buttons, caps_on: false }
    }

    /// Рисует клавиатуру, подсвечивая кнопку под курсором.
    pub fn draw(&self, cur_x: u16, cur_y: u16) {
        use std::io::Write;

        for btn in &self.buttons {
            let ansi_x = btn.x + 1;
            let ansi_y = btn.y + 1;

            let over = cur_y == btn.y && cur_x >= btn.x && cur_x < btn.x + btn.width;
            let caps_highlighted = btn.special == Special::CapsLock && self.caps_on;

            if over || caps_highlighted {
                print!("\x1b[{};{}H\x1b[7m", ansi_y, ansi_x);
                Self::draw_button_body(btn);
                print!("\x1b[0m");
            } else {
                print!("\x1b[{};{}H", ansi_y, ansi_x);
                Self::draw_button_body(btn);
            }
        }

        let _ = std::io::stdout().flush();
    }

    fn draw_button_body(btn: &Button) {
        print!("[");
        match btn.special {
            Special::Space => {
                for _ in 0..btn.width.saturating_sub(2) {
                    print!(" ");
                }
            }
            _ => {
                print!("{}", btn.label);
                let label_len = btn.label.chars().count() as u16;
                for _ in 0..btn.width.saturating_sub(label_len + 2) {
                    print!(" ");
                }
            }
        }
        print!("]");
    }

    pub fn hit(&self, x: u16, y: u16) -> Option<&Button> {
        self.buttons.iter().find(|btn| {
            y == btn.y && x >= btn.x && x < btn.x + btn.width
        })
    }

    pub fn char_from(&self, btn: &Button) -> Option<char> {
        if let Some(c) = btn.value {
            if btn.special == Special::Space {
                return Some(' ');
            }
            if self.caps_on {
                Some(c.to_ascii_uppercase())
            } else {
                Some(c.to_ascii_lowercase())
            }
        } else {
            None
        }
    }
}