//! # TUI 🎯
//!
//! Минимальный терминальный интерфейс: курсор + кнопки + клавиатура.

pub mod cursor;
pub mod buttons;
pub mod board;